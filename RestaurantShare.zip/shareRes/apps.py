from django.apps import AppConfig


class ShareresConfig(AppConfig):
    name = 'shareRes'
